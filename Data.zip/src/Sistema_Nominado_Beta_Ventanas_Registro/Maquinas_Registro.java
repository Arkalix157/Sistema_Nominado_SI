package Sistema_Nominado_Beta_Ventanas_Registro;

import Sistema_Nominado_Beta.Login_Online;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import Sistema_Nominado_Beta_Succes_Screens.usr_registro_succes_general;


/**
 *
 * @author julio
 */
public class Maquinas_Registro extends javax.swing.JFrame {

    Sistema_Nominado_Beta.Panel_Central pan_central = new Sistema_Nominado_Beta.Panel_Central();
    Connection con = null;
    Statement stmt = null;

    public Maquinas_Registro() {
        initComponents();
        
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txt_nom = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txt_serie = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        exit_btn = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        txt_modelo = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txt_nom2 = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        txt_planta_maquina_instalada = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jSeparator5 = new javax.swing.JSeparator();
        jLabel14 = new javax.swing.JLabel();
        jSeparator6 = new javax.swing.JSeparator();
        txt_idOperador = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(46, 52, 64));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(46, 52, 64));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txt_nom.setBackground(new java.awt.Color(46, 52, 64));
        txt_nom.setFont(new java.awt.Font("Hack NF", 0, 14)); // NOI18N
        txt_nom.setForeground(new java.awt.Color(255, 255, 255));
        txt_nom.setBorder(null);
        txt_nom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nomActionPerformed(evt);
            }
        });
        txt_nom.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_nomKeyTyped(evt);
            }
        });
        jPanel1.add(txt_nom, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 300, 187, -1));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 320, 187, 10));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/Fundilag_logo_v1.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 0, -1, -1));

        jLabel3.setFont(new java.awt.Font("Hack Nerd Font Mono", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Hierro");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 70, -1, -1));

        txt_serie.setBackground(new java.awt.Color(46, 52, 64));
        txt_serie.setFont(new java.awt.Font("Hack NF", 0, 14)); // NOI18N
        txt_serie.setForeground(new java.awt.Color(255, 255, 255));
        txt_serie.setBorder(null);
        txt_serie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_serieActionPerformed(evt);
            }
        });
        txt_serie.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_serieKeyTyped(evt);
            }
        });
        jPanel1.add(txt_serie, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 510, 187, -1));
        jPanel1.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 530, 187, 10));

        jLabel5.setFont(new java.awt.Font("Hack Nerd Font Mono", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Serie (Max. 25 Caract.)");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 470, -1, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/icons8_robot_30px.png"))); // NOI18N
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 500, -1, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/icons8_geothermal_90px.png"))); // NOI18N
        jLabel7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 190, -1, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/icons8_pump_30px.png"))); // NOI18N
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, -1, 30));

        jLabel9.setFont(new java.awt.Font("Hack Nerd Font Mono", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("ID De la Maquina");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 160, -1, -1));

        jLabel10.setFont(new java.awt.Font("Hack Nerd Font Mono", 0, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Fundilag");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 40, -1, -1));

        exit_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/exit_icon_1.png"))); // NOI18N
        exit_btn.setBorderPainted(false);
        exit_btn.setContentAreaFilled(false);
        exit_btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        exit_btn.setFocusPainted(false);
        exit_btn.setFocusable(false);
        exit_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exit_btnActionPerformed(evt);
            }
        });
        jPanel1.add(exit_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 20, 40, 40));
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 420, 187, 10));

        txt_modelo.setBackground(new java.awt.Color(46, 52, 64));
        txt_modelo.setFont(new java.awt.Font("Hack NF", 0, 14)); // NOI18N
        txt_modelo.setForeground(new java.awt.Color(255, 255, 255));
        txt_modelo.setBorder(null);
        txt_modelo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_modeloActionPerformed(evt);
            }
        });
        txt_modelo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_modeloKeyTyped(evt);
            }
        });
        jPanel1.add(txt_modelo, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 400, 187, -1));

        jLabel11.setFont(new java.awt.Font("Hack Nerd Font Mono", 0, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Modelo (Max. 15 Caract.)");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 370, -1, -1));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/icons8_circuit_30px.png"))); // NOI18N
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 400, -1, -1));

        txt_nom2.setBackground(new java.awt.Color(46, 52, 64));
        txt_nom2.setFont(new java.awt.Font("Hack NF", 0, 14)); // NOI18N
        txt_nom2.setForeground(new java.awt.Color(255, 255, 255));
        txt_nom2.setBorder(null);
        txt_nom2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nom2ActionPerformed(evt);
            }
        });
        txt_nom2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_nom2KeyTyped(evt);
            }
        });
        jPanel1.add(txt_nom2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 300, 187, -1));

        jLabel13.setFont(new java.awt.Font("Hack Nerd Font Mono", 0, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Nombre De La Maquina");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 270, -1, -1));
        jPanel1.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 630, 187, 10));

        txt_planta_maquina_instalada.setBackground(new java.awt.Color(46, 52, 64));
        txt_planta_maquina_instalada.setFont(new java.awt.Font("Hack NF", 0, 14)); // NOI18N
        txt_planta_maquina_instalada.setForeground(new java.awt.Color(255, 255, 255));
        txt_planta_maquina_instalada.setBorder(null);
        txt_planta_maquina_instalada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_planta_maquina_instaladaActionPerformed(evt);
            }
        });
        txt_planta_maquina_instalada.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_planta_maquina_instaladaKeyTyped(evt);
            }
        });
        jPanel1.add(txt_planta_maquina_instalada, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 610, 187, -1));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/icons8_address_30px.png"))); // NOI18N
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 610, -1, -1));

        jLabel17.setFont(new java.awt.Font("Hack Nerd Font Mono", 0, 18)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Planta De Destino (Max. 40 Caract.)");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 580, -1, -1));
        jPanel1.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 190, -1, -1));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/icons8_turbocharger_30px.png"))); // NOI18N
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 300, -1, -1));
        jPanel1.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 230, 200, 10));

        txt_idOperador.setEditable(false);
        txt_idOperador.setBackground(new java.awt.Color(46, 52, 64));
        txt_idOperador.setFont(new java.awt.Font("Hack NF", 0, 14)); // NOI18N
        txt_idOperador.setForeground(new java.awt.Color(255, 255, 255));
        txt_idOperador.setText("Generado Automaticamente");
        txt_idOperador.setBorder(null);
        txt_idOperador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_idOperadorActionPerformed(evt);
            }
        });
        txt_idOperador.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_idOperadorKeyTyped(evt);
            }
        });
        jPanel1.add(txt_idOperador, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 210, 200, -1));

        jLabel18.setFont(new java.awt.Font("Hack Nerd Font Mono", 1, 24)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("REGISTRAR MAQUINA");
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 310, -1, -1));
        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 630, 5, 50));
        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 150, 5, 200));
        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 400, 5, 50));
        jPanel1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 510, 5, 50));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 660, 740));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txt_nomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nomActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nomActionPerformed

    private void txt_serieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_serieActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_serieActionPerformed

    private void txt_nomKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_nomKeyTyped
        char c = evt.getKeyChar();
        if ((c<'a' || c>'z') && (c<'A' || c>'Z') && (c<' ' || c>' ')) evt.consume();
    }//GEN-LAST:event_txt_nomKeyTyped

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        String nombre_maquina, modelo_maquina, serie_maquina, planta_maquina_instalada;

         nombre_maquina = txt_nom.getText();
         modelo_maquina = txt_modelo.getText();
         serie_maquina = this.txt_serie.getText();
         planta_maquina_instalada = txt_planta_maquina_instalada.getText();
         

        if (txt_nom.getText().equals("") || (txt_modelo.getText().equals("")) || (this.txt_serie.getText().equals("")) || (txt_planta_maquina_instalada.getText().equals("")))
        {
            javax.swing.JOptionPane.showMessageDialog(this,"Se encontraron campos vacios!, debe llenarlos! \n","[!] ERROR",javax.swing.JOptionPane.INFORMATION_MESSAGE);
            txt_nom.requestFocus();
        }
            else {
        try {

            String url = "jdbc:mysql://localhost:3306/centraldata_sis_nom_fundilag";
            String usuario = "root";
            String contraseña = "";

             Class.forName("com.mysql.jdbc.Driver").newInstance();
             con = DriverManager.getConnection(url,usuario,contraseña);
             if ( con != null )
                    System.out.println("Se conecto a la base de datos de fundilag hierro!" +
                                       "\n " + url );
                  stmt = con.createStatement();
                  stmt.executeUpdate("INSERT INTO maquinas VALUES('" + 0 + "','"+nombre_maquina+"','"+modelo_maquina+"','"+serie_maquina+"','"+planta_maquina_instalada+"')");
                  System.out.println("Maquina registrada con exito! | FUNDILAG HIERRO");
                  


        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException ex) {
           Logger.getLogger(Maquinas_Registro.class.getName()).log(Level.SEVERE, null, ex);
       }

        finally {
            if (con != null) {
                try {
                    con.close();
                    stmt.close();
                } catch ( SQLException e ) {
                         System.out.println( e.getMessage());
                }
            }
        }
         this.setVisible(false);
         javax.swing.JOptionPane.showMessageDialog(this,"Registro de maquina exitoso! \n","FUNDILAG: TAREA TERMINADA!",javax.swing.JOptionPane.INFORMATION_MESSAGE);
         usr_registro_succes_general succes = new usr_registro_succes_general();
         succes.setVisible(true);
        }
        this.txt_nom.setText("");
        this.txt_serie.setText("");


    }//GEN-LAST:event_jLabel7MouseClicked

    private void exit_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exit_btnActionPerformed
        System.out.println("[!] Saliendo del registro para maquinas.");
        this.setVisible(false);
        pan_central.setVisible(true);
    }//GEN-LAST:event_exit_btnActionPerformed

    private void txt_modeloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_modeloActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_modeloActionPerformed

    private void txt_modeloKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_modeloKeyTyped
        if(txt_modelo.getText().length() >= 15)
        {
        javax.swing.JOptionPane.showMessageDialog(this,"La cantidad de caracteres ingresados sobrepasaron el limite permitido! \n","FUNDILAG: CARACTERES EXCEDIDOS!",javax.swing.JOptionPane.WARNING_MESSAGE);
        evt.consume();
        }
    }//GEN-LAST:event_txt_modeloKeyTyped

    private void txt_nom2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nom2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nom2ActionPerformed

    private void txt_nom2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_nom2KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nom2KeyTyped

    private void txt_planta_maquina_instaladaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_planta_maquina_instaladaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_planta_maquina_instaladaActionPerformed

    private void txt_planta_maquina_instaladaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_planta_maquina_instaladaKeyTyped
        if(txt_planta_maquina_instalada.getText().length() >= 40)
        {
        javax.swing.JOptionPane.showMessageDialog(this,"La cantidad de caracteres ingresados sobrepasaron el limite permitido! \n","FUNDILAG: CARACTERES EXCEDIDOS!",javax.swing.JOptionPane.WARNING_MESSAGE);
        evt.consume();
        }
    }//GEN-LAST:event_txt_planta_maquina_instaladaKeyTyped

    private void txt_serieKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_serieKeyTyped

        if(txt_serie.getText().length() >= 25)
        {
        javax.swing.JOptionPane.showMessageDialog(this,"La cantidad de caracteres ingresados sobrepasaron el limite permitido! \n","FUNDILAG: CARACTERES EXCEDIDOS!",javax.swing.JOptionPane.WARNING_MESSAGE);
        evt.consume();
        }
    }//GEN-LAST:event_txt_serieKeyTyped

    private void txt_idOperadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_idOperadorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_idOperadorActionPerformed

    private void txt_idOperadorKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_idOperadorKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_idOperadorKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Maquinas_Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Maquinas_Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Maquinas_Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Maquinas_Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Maquinas_Registro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton exit_btn;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JTextField txt_idOperador;
    private javax.swing.JTextField txt_modelo;
    private javax.swing.JTextField txt_nom;
    private javax.swing.JTextField txt_nom2;
    private javax.swing.JTextField txt_planta_maquina_instalada;
    private javax.swing.JTextField txt_serie;
    // End of variables declaration//GEN-END:variables
}
