package Sistema_Nominado_Beta_Ventanas_Registro;

import Sistema_Nominado_Beta.Login_Online;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import Sistema_Nominado_Beta_Succes_Screens.usr_registro_succes_general;


/**
 *
 * @author julio
 */
public class Trabajador_Mantenimiento_registro1 extends javax.swing.JFrame {

    Sistema_Nominado_Beta.Panel_Central pan_central = new Sistema_Nominado_Beta.Panel_Central();
    Connection con = null;
    Statement stmt = null;

    public Trabajador_Mantenimiento_registro1() {
        initComponents();
        
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txt_nom = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        num_Telefono = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        exit_btn = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        txt_direccion = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txt_nom2 = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        txt_RFC = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jSeparator5 = new javax.swing.JSeparator();
        jLabel14 = new javax.swing.JLabel();
        jSeparator6 = new javax.swing.JSeparator();
        txt_idOperador = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(46, 52, 64));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(46, 52, 64));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txt_nom.setBackground(new java.awt.Color(46, 52, 64));
        txt_nom.setFont(new java.awt.Font("Hack NF", 0, 14)); // NOI18N
        txt_nom.setForeground(new java.awt.Color(255, 255, 255));
        txt_nom.setBorder(null);
        txt_nom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nomActionPerformed(evt);
            }
        });
        txt_nom.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_nomKeyTyped(evt);
            }
        });
        jPanel1.add(txt_nom, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 300, 187, -1));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 320, 187, 10));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/Fundilag_logo_v1.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 0, -1, -1));

        jLabel3.setFont(new java.awt.Font("Hack Nerd Font Mono", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Hierro");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 70, -1, -1));

        num_Telefono.setBackground(new java.awt.Color(46, 52, 64));
        num_Telefono.setFont(new java.awt.Font("Hack NF", 0, 14)); // NOI18N
        num_Telefono.setForeground(new java.awt.Color(255, 255, 255));
        num_Telefono.setBorder(null);
        num_Telefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                num_TelefonoActionPerformed(evt);
            }
        });
        num_Telefono.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                num_TelefonoKeyTyped(evt);
            }
        });
        jPanel1.add(num_Telefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 510, 187, -1));
        jPanel1.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 530, 187, 10));

        jLabel5.setFont(new java.awt.Font("Hack Nerd Font Mono", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Telefono (Max. 12 Digitos).");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 470, -1, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/icons8_phone_30px.png"))); // NOI18N
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 500, -1, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/icons8_construction_workers_90px.png"))); // NOI18N
        jLabel7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 240, -1, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/icons8_profiles_30px.png"))); // NOI18N
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, -1, 30));

        jLabel9.setFont(new java.awt.Font("Hack Nerd Font Mono", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("ID Del Trabajador");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 160, -1, -1));

        jLabel10.setFont(new java.awt.Font("Hack Nerd Font Mono", 0, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Fundilag");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 40, -1, -1));

        exit_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/exit_icon_1.png"))); // NOI18N
        exit_btn.setBorderPainted(false);
        exit_btn.setContentAreaFilled(false);
        exit_btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        exit_btn.setFocusPainted(false);
        exit_btn.setFocusable(false);
        exit_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exit_btnActionPerformed(evt);
            }
        });
        jPanel1.add(exit_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 20, 40, 40));
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 420, 187, 10));

        txt_direccion.setBackground(new java.awt.Color(46, 52, 64));
        txt_direccion.setFont(new java.awt.Font("Hack NF", 0, 14)); // NOI18N
        txt_direccion.setForeground(new java.awt.Color(255, 255, 255));
        txt_direccion.setBorder(null);
        txt_direccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_direccionActionPerformed(evt);
            }
        });
        txt_direccion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_direccionKeyTyped(evt);
            }
        });
        jPanel1.add(txt_direccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 400, 187, -1));

        jLabel11.setFont(new java.awt.Font("Hack Nerd Font Mono", 0, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Direccion");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 370, -1, -1));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/icons8_user_location_30px_1.png"))); // NOI18N
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 400, -1, -1));

        txt_nom2.setBackground(new java.awt.Color(46, 52, 64));
        txt_nom2.setFont(new java.awt.Font("Hack NF", 0, 14)); // NOI18N
        txt_nom2.setForeground(new java.awt.Color(255, 255, 255));
        txt_nom2.setBorder(null);
        txt_nom2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nom2ActionPerformed(evt);
            }
        });
        txt_nom2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_nom2KeyTyped(evt);
            }
        });
        jPanel1.add(txt_nom2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 300, 187, -1));

        jLabel13.setFont(new java.awt.Font("Hack Nerd Font Mono", 0, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Nombre Del Trabajador");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 270, -1, -1));
        jPanel1.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 630, 187, 10));

        txt_RFC.setBackground(new java.awt.Color(46, 52, 64));
        txt_RFC.setFont(new java.awt.Font("Hack NF", 0, 14)); // NOI18N
        txt_RFC.setForeground(new java.awt.Color(255, 255, 255));
        txt_RFC.setBorder(null);
        txt_RFC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_RFCActionPerformed(evt);
            }
        });
        txt_RFC.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_RFCKeyTyped(evt);
            }
        });
        jPanel1.add(txt_RFC, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 610, 187, -1));

        jLabel15.setFont(new java.awt.Font("Hack Nerd Font Mono", 1, 24)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("  DE MANTENIMIENTO");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 390, -1, -1));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/icons8_activity_feed_30px.png"))); // NOI18N
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 610, -1, -1));

        jLabel17.setFont(new java.awt.Font("Hack Nerd Font Mono", 0, 18)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("RFC (Max. 13 Caract.)");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 580, -1, -1));
        jPanel1.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 190, -1, -1));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/icons8_name_30px_2.png"))); // NOI18N
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 300, -1, -1));
        jPanel1.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 230, 200, 10));

        txt_idOperador.setEditable(false);
        txt_idOperador.setBackground(new java.awt.Color(46, 52, 64));
        txt_idOperador.setFont(new java.awt.Font("Hack NF", 0, 14)); // NOI18N
        txt_idOperador.setForeground(new java.awt.Color(255, 255, 255));
        txt_idOperador.setText("Generado Automaticamente");
        txt_idOperador.setBorder(null);
        txt_idOperador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_idOperadorActionPerformed(evt);
            }
        });
        txt_idOperador.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_idOperadorKeyTyped(evt);
            }
        });
        jPanel1.add(txt_idOperador, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 210, 200, -1));

        jLabel18.setFont(new java.awt.Font("Hack Nerd Font Mono", 1, 24)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("REGISTRAR TRABAJADOR");
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 360, -1, -1));
        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 160, 5, 280));
        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 510, 5, 50));
        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 620, 5, 50));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 660, 740));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txt_nomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nomActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nomActionPerformed

    private void num_TelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_num_TelefonoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_num_TelefonoActionPerformed

    private void txt_nomKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_nomKeyTyped
        char c = evt.getKeyChar();
        if ((c<'a' || c>'z') && (c<'A' || c>'Z') && (c<' ' || c>' ')) evt.consume();
    }//GEN-LAST:event_txt_nomKeyTyped

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        String nombre_mtto, direccion_mtto, numero_tel_mtto, rfc;

         nombre_mtto = txt_nom.getText();
         direccion_mtto = txt_direccion.getText();
         numero_tel_mtto = num_Telefono.getText();
         rfc = txt_RFC.getText();
         

        if (txt_nom.getText().equals("") || (txt_direccion.getText().equals("")) || (num_Telefono.getText().equals("")) || (txt_RFC.getText().equals("")))
        {
            javax.swing.JOptionPane.showMessageDialog(this,"Se encontraron campos vacios!, debe llenarlos! \n","[!] ERROR",javax.swing.JOptionPane.INFORMATION_MESSAGE);
            txt_nom.requestFocus();
        }
            else {
        try {

            String url = "jdbc:mysql://localhost:3306/centraldata_sis_nom_fundilag";
            String usuario = "root";
            String contraseña = "";

             Class.forName("com.mysql.jdbc.Driver").newInstance();
             con = DriverManager.getConnection(url,usuario,contraseña);
             if ( con != null )
                    System.out.println("Se conecto a la base de datos de fundilag hierro!" +
                                       "\n " + url );
                  stmt = con.createStatement();
                  stmt.executeUpdate("INSERT INTO mantenimiento VALUES('" + 0 + "','"+nombre_mtto+"','"+direccion_mtto+"','"+numero_tel_mtto+"','"+rfc+"')");
                  System.out.println("Trabajador en mantenimiento registrado con exito! | FUNDILAG HIERRO");
                  


        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException ex) {
           Logger.getLogger(Trabajador_Mantenimiento_registro1.class.getName()).log(Level.SEVERE, null, ex);
       }

        finally {
            if (con != null) {
                try {
                    con.close();
                    stmt.close();
                } catch ( SQLException e ) {
                         System.out.println( e.getMessage());
                }
            }
        }
         this.setVisible(false);
         javax.swing.JOptionPane.showMessageDialog(this,"Registro de trabajador en mantenimiento exitoso! \n","FUNDILAG: TAREA TERMINADA!",javax.swing.JOptionPane.INFORMATION_MESSAGE);
         usr_registro_succes_general succes = new usr_registro_succes_general();
         succes.setVisible(true);
        }
        this.txt_nom.setText("");
        this.num_Telefono.setText("");


    }//GEN-LAST:event_jLabel7MouseClicked

    private void exit_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exit_btnActionPerformed
        System.out.println("[!] Saliendo del registro para trabajadores en mantenimiento.");
        this.setVisible(false);
        pan_central.setVisible(true);
    }//GEN-LAST:event_exit_btnActionPerformed

    private void txt_direccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_direccionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_direccionActionPerformed

    private void txt_direccionKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_direccionKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_direccionKeyTyped

    private void txt_nom2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nom2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nom2ActionPerformed

    private void txt_nom2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_nom2KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nom2KeyTyped

    private void txt_RFCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_RFCActionPerformed
        
    }//GEN-LAST:event_txt_RFCActionPerformed

    private void txt_RFCKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_RFCKeyTyped
        if(txt_RFC.getText().length() >= 13)
        {
        javax.swing.JOptionPane.showMessageDialog(this,"La cantidad de caracteres ingresados sobrepasaron el limite permitido! \n","FUNDILAG: CARACTERES EXCEDIDOS!",javax.swing.JOptionPane.WARNING_MESSAGE);
        evt.consume();
        }
    }//GEN-LAST:event_txt_RFCKeyTyped

    private void num_TelefonoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_num_TelefonoKeyTyped
       char c = evt.getKeyChar();
                if (c<'0' || c>'9') evt.consume();
        if(num_Telefono.getText().length() >= 12)
        {
        javax.swing.JOptionPane.showMessageDialog(this,"La cantidad de caracteres ingresados sobrepasaron el limite permitido! \n","FUNDILAG: CARACTERES EXCEDIDOS!",javax.swing.JOptionPane.WARNING_MESSAGE);
        evt.consume();
        }        
    }//GEN-LAST:event_num_TelefonoKeyTyped

    private void txt_idOperadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_idOperadorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_idOperadorActionPerformed

    private void txt_idOperadorKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_idOperadorKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_idOperadorKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Trabajador_Mantenimiento_registro1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Trabajador_Mantenimiento_registro1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Trabajador_Mantenimiento_registro1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Trabajador_Mantenimiento_registro1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Trabajador_Mantenimiento_registro1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton exit_btn;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JTextField num_Telefono;
    private javax.swing.JTextField txt_RFC;
    private javax.swing.JTextField txt_direccion;
    private javax.swing.JTextField txt_idOperador;
    private javax.swing.JTextField txt_nom;
    private javax.swing.JTextField txt_nom2;
    // End of variables declaration//GEN-END:variables
}
