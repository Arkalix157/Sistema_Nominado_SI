package Sistema_Nominado_Beta;
import Sistema_Nominado_Beta.Login_Online;


/**
 *
 * @author sheogorath
 */
    public class usr_session {

    }
