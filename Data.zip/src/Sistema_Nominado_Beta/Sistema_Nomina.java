package Sistema_Nominado_Beta;

/**
 *
 * @author sheogorath
 */
public class Sistema_Nomina {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
