
package Sistema_Nominado_Beta;

import Sistema_Nominado_Beta_Ventanas_Registro.Operadores_registro;
import java.sql.SQLException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;


/**
 *
 * @author sheogorath
 */
public class Login_Online extends javax.swing.JFrame {    
    private static String usr_nm;
    public Login_Online() {
        initComponents();   
    }
    
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        exit_btn = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        campo_usr = new javax.swing.JTextField();
        campo_psw = new javax.swing.JPasswordField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btn_Login = new javax.swing.JButton();
        Reg_Btn_NMN = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        exit_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/exit_icon_1.png"))); // NOI18N
        exit_btn.setBorderPainted(false);
        exit_btn.setContentAreaFilled(false);
        exit_btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        exit_btn.setFocusPainted(false);
        exit_btn.setFocusable(false);
        exit_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exit_btnActionPerformed(evt);
            }
        });
        getContentPane().add(exit_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 10, 40, 40));

        jPanel3.setBackground(new java.awt.Color(59, 66, 82));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/Fundilag_logo_v1.png"))); // NOI18N
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 10, -1, -1));

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/Montaje_Org_Ind_1.gif"))); // NOI18N
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 390, 170));
        jPanel3.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 320, 280, 10));
        jPanel3.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 240, 280, 10));

        campo_usr.setBackground(new java.awt.Color(59, 66, 82));
        campo_usr.setFont(new java.awt.Font("FantasqueSansMono Nerd Font", 0, 14)); // NOI18N
        campo_usr.setForeground(new java.awt.Color(255, 255, 255));
        campo_usr.setBorder(null);
        campo_usr.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                campo_usrKeyTyped(evt);
            }
        });
        jPanel3.add(campo_usr, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 200, 280, 40));

        campo_psw.setBackground(new java.awt.Color(59, 66, 82));
        campo_psw.setFont(new java.awt.Font("FantasqueSansMono Nerd Font", 0, 14)); // NOI18N
        campo_psw.setForeground(new java.awt.Color(255, 255, 255));
        campo_psw.setBorder(null);
        campo_psw.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                campo_pswKeyTyped(evt);
            }
        });
        jPanel3.add(campo_psw, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 280, 280, 40));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/password_lock_img_1.png"))); // NOI18N
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, 40, 40));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/usr_icon_1_min.png"))); // NOI18N
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 40, 40));

        btn_Login.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btn_Login.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/icons8_login_80px.png"))); // NOI18N
        btn_Login.setBorderPainted(false);
        btn_Login.setContentAreaFilled(false);
        btn_Login.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_Login.setFocusPainted(false);
        btn_Login.setFocusable(false);
        btn_Login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_LoginActionPerformed(evt);
            }
        });
        jPanel3.add(btn_Login, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 390, 80, 70));

        Reg_Btn_NMN.setFont(new java.awt.Font("Candara Light", 0, 18)); // NOI18N
        Reg_Btn_NMN.setForeground(new java.awt.Color(255, 255, 255));
        Reg_Btn_NMN.setText("No tienes cuenta?");
        Reg_Btn_NMN.setToolTipText("");
        Reg_Btn_NMN.setBorderPainted(false);
        Reg_Btn_NMN.setContentAreaFilled(false);
        Reg_Btn_NMN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Reg_Btn_NMN.setFocusPainted(false);
        Reg_Btn_NMN.setFocusable(false);
        Reg_Btn_NMN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                Reg_Btn_NMNMousePressed(evt);
            }
        });
        Reg_Btn_NMN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Reg_Btn_NMNActionPerformed(evt);
            }
        });
        jPanel3.add(Reg_Btn_NMN, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 570, 170, 20));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 390, 600));

        jPanel1.setBackground(new java.awt.Color(39, 49, 62));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/Maquina_Preexp_1.png"))); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 107, 603, -1));

        jLabel6.setFont(new java.awt.Font("JetBrains Mono", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Sistema De Nominado");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(387, 61, 147, 40));

        jLabel7.setFont(new java.awt.Font("Fira Sans Ultra", 1, 30)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("FUNDILAG HIERRO S.A DE C.V");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(84, 15, 450, 40));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 0, 610, 600));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void campo_usrKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campo_usrKeyTyped
        char c = evt.getKeyChar();
        if ((c<'a' || c>'z') && (c<'A' || c>'Z') && (c<' ' || c>' ')) evt.consume();
    }//GEN-LAST:event_campo_usrKeyTyped

    private void campo_pswKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campo_pswKeyTyped
       
    }//GEN-LAST:event_campo_pswKeyTyped

    private void Reg_Btn_NMNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Reg_Btn_NMNActionPerformed
        setVisible(false);
        System.out.println("[!] Se ingreso al menu de registro.");
    }//GEN-LAST:event_Reg_Btn_NMNActionPerformed

    private void exit_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exit_btnActionPerformed
        System.out.println("[-] Saliendo del sistema.");
        System.exit(0);
    }//GEN-LAST:event_exit_btnActionPerformed

    private void btn_LoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_LoginActionPerformed
        try {

            ConectarSQL_nmn Con = new ConectarSQL_nmn();
            String u = campo_usr.getText();
            String c = campo_psw.getText();
            Con.ConectarBasedeDatos();
            String SQL = "SELECT COUNT(usrID) AS i FROM usuarios WHERE nm_user ='"+u+"'" + " AND psw = '"+c+"'";
            Con.resultado = Con.sentencia.executeQuery(SQL);
            
            while (Con.resultado.next()){
                if (Con.resultado.getString("i").equals("1")) {

                    this.hide();
                    Panel_Central menu = new Panel_Central();
                    usr_nm = campo_usr.getText();

                    JOptionPane.showMessageDialog(null, "Informacion:\nEl acceso concluyo satisfactoriamente!", "Bienvenido "+u+"!", WIDTH);
                    System.out.println("Sesion iniciada como: "+usr_nm);
                    
                    this.campo_usr.setText("");
                    this.campo_psw.setText("");
                    menu.setVisible(true);

                }else {

                    JOptionPane.showMessageDialog(null, "Error:\nContraseña y/o usuario incorrectos.\nPor favor intentelo de nuevo.","Error al iniciar", JOptionPane.ERROR_MESSAGE);
                    System.out.println("Intento de inicio de sesion erroneo.");
                }
            }
            Con.DesconectarBasedeDatos();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }//GEN-LAST:event_btn_LoginActionPerformed

    private void Reg_Btn_NMNMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Reg_Btn_NMNMousePressed

        System.out.println("[!] Se ingreso al menu de registro.");
        dispose();
        Ventanas_loading.ventana_loading_regUsuario venload = new Ventanas_loading.ventana_loading_regUsuario();
        venload.setVisible(true);
    }//GEN-LAST:event_Reg_Btn_NMNMousePressed

    
    public static void main(String args[]) {
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Login_Online().setVisible(true);
            
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton Reg_Btn_NMN;
    public javax.swing.JButton btn_Login;
    public javax.swing.JPasswordField campo_psw;
    public javax.swing.JTextField campo_usr;
    public javax.swing.JButton exit_btn;
    public javax.swing.JLabel jLabel1;
    public javax.swing.JLabel jLabel2;
    public javax.swing.JLabel jLabel3;
    public javax.swing.JLabel jLabel5;
    public javax.swing.JLabel jLabel6;
    public javax.swing.JLabel jLabel7;
    public javax.swing.JLabel jLabel8;
    public javax.swing.JPanel jPanel1;
    public javax.swing.JPanel jPanel3;
    public javax.swing.JSeparator jSeparator1;
    public javax.swing.JSeparator jSeparator2;
    // End of variables declaration//GEN-END:variables
}