package Sistema_Nominado_Beta;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import Sistema_Nominado_Beta_Succes_Screens.usr_registro_succes;


/**
 *
 * @author julio
 */
public class usr_registro_acces extends javax.swing.JFrame {


    Connection con = null;
    Statement stmt = null;

    public usr_registro_acces() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txt_nom = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txt_area_trab = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        pass = new javax.swing.JPasswordField();
        exit_btn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(46, 52, 64));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(46, 52, 64));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Hack Nerd Font Mono", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Nueva contraseña (Max. 30 Caract.)");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 262, 440, -1));

        txt_nom.setBackground(new java.awt.Color(46, 52, 64));
        txt_nom.setFont(new java.awt.Font("Hack NF", 0, 14)); // NOI18N
        txt_nom.setForeground(new java.awt.Color(255, 255, 255));
        txt_nom.setBorder(null);
        txt_nom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_nomActionPerformed(evt);
            }
        });
        txt_nom.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_nomKeyTyped(evt);
            }
        });
        jPanel1.add(txt_nom, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, 330, -1));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 222, 330, 10));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/Fundilag_logo_v1.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 0, -1, -1));
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 319, 330, 10));

        jLabel3.setFont(new java.awt.Font("Hack Nerd Font Mono", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Hierro");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 60, -1, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/con_usr_reg_1.png"))); // NOI18N
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(46, 290, -1, -1));

        txt_area_trab.setBackground(new java.awt.Color(46, 52, 64));
        txt_area_trab.setFont(new java.awt.Font("Hack NF", 0, 14)); // NOI18N
        txt_area_trab.setForeground(new java.awt.Color(255, 255, 255));
        txt_area_trab.setBorder(null);
        txt_area_trab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_area_trabActionPerformed(evt);
            }
        });
        txt_area_trab.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_area_trabKeyTyped(evt);
            }
        });
        jPanel1.add(txt_area_trab, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 390, 330, -1));
        jPanel1.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 412, 330, 10));

        jLabel5.setFont(new java.awt.Font("Hack Nerd Font Mono", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Planta de trabajo (Max. 40 Caract.)");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 355, -1, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/icons8_user_location_30px_1.png"))); // NOI18N
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(48, 383, -1, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/btn_registrar_css_style_1.png"))); // NOI18N
        jLabel7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 470, -1, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/icons8_name_30px_2.png"))); // NOI18N
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, -1, -1));

        jLabel9.setFont(new java.awt.Font("Hack Nerd Font Mono", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Nombre de usuario (Max. 50 Caract.)");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 165, -1, -1));

        jLabel10.setFont(new java.awt.Font("Hack Nerd Font Mono", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Fundilag");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 40, -1, -1));

        pass.setBackground(new java.awt.Color(46, 52, 64));
        pass.setFont(new java.awt.Font("Hack NF", 0, 14)); // NOI18N
        pass.setForeground(new java.awt.Color(255, 255, 255));
        pass.setBorder(null);
        pass.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                passKeyTyped(evt);
            }
        });
        jPanel1.add(pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 300, 320, -1));

        exit_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Sistema_Nominado_Media/RSS/exit_icon_1.png"))); // NOI18N
        exit_btn.setBorderPainted(false);
        exit_btn.setContentAreaFilled(false);
        exit_btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        exit_btn.setFocusPainted(false);
        exit_btn.setFocusable(false);
        exit_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exit_btnActionPerformed(evt);
            }
        });
        jPanel1.add(exit_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 10, 40, 40));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 530, 650));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txt_nomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_nomActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_nomActionPerformed

    private void txt_area_trabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_area_trabActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_area_trabActionPerformed

    private void txt_nomKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_nomKeyTyped
        char c = evt.getKeyChar();
        if ((c<'a' || c>'z') && (c<'A' || c>'Z') && (c<' ' || c>' ')) evt.consume();
        if(txt_nom.getText().length() >= 30)
        {
        javax.swing.JOptionPane.showMessageDialog(this,"La cantidad de caracteres ingresados sobrepasaron el limite permitido! \n","FUNDILAG: CARACTERES EXCEDIDOS!",javax.swing.JOptionPane.WARNING_MESSAGE);
        evt.consume();
        }
    }//GEN-LAST:event_txt_nomKeyTyped

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        String nombre_usuario, passw, planta_trabajo;

        nombre_usuario = txt_nom.getText();
         planta_trabajo = txt_area_trab.getText();
         passw = pass.getText().toString();


        if (txt_nom.getText().equals("") || (txt_area_trab.getText().equals("")) || (pass.getText().equals("")))
        {
            javax.swing.JOptionPane.showMessageDialog(this,"Se encontraron campos vacios!, debe llenarlos! \n","[!] ERROR",javax.swing.JOptionPane.INFORMATION_MESSAGE);
            txt_nom.requestFocus();
        }
            else {
        try {

            String url = "jdbc:mysql://localhost:3306/centraldata_sis_nom_fundilag";
            String usuario = "root";
            String contraseña = "";

             Class.forName("com.mysql.jdbc.Driver").newInstance();
             con = DriverManager.getConnection(url,usuario,contraseña);
             if ( con != null )
                    System.out.println("Se conecto a la base de datos de fundilag hierro!" +
                                       "\n " + url );
                  stmt = con.createStatement();
                  stmt.executeUpdate("INSERT INTO usuarios VALUES('" + 0 + "','"+nombre_usuario+"','"+passw+"','"+planta_trabajo+"')");
                  System.out.println("Usuario registrado con exito! | FUNDILAG HIERRO");
                  


        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException ex) {
           Logger.getLogger(usr_registro_acces.class.getName()).log(Level.SEVERE, null, ex);
       }

        finally {
            if (con != null) {
                try {
                    con.close();
                    stmt.close();
                } catch ( SQLException e ) {
                         System.out.println( e.getMessage());
                }
            }
        }
         this.setVisible(false);
         javax.swing.JOptionPane.showMessageDialog(this,"Registro de usuario exitoso! \n","FUNDILAG: TAREA TERMINADA!",javax.swing.JOptionPane.INFORMATION_MESSAGE);
         usr_registro_succes succes = new usr_registro_succes();
         succes.setVisible(true);
        }
        this.txt_nom.setText("");
        this.txt_area_trab.setText("");
        this.pass.setText("");

    }//GEN-LAST:event_jLabel7MouseClicked

    private void exit_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exit_btnActionPerformed
        System.out.println("[!] Saliendo del menu de registro para usuarios.");
        this.setVisible(false);
        Login_Online log_on = new Login_Online();
        log_on.setVisible(true);
    }//GEN-LAST:event_exit_btnActionPerformed

    private void passKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_passKeyTyped
        if(pass.getText().length() >= 15)
        {
        javax.swing.JOptionPane.showMessageDialog(this,"La cantidad de caracteres ingresados sobrepasaron el limite permitido! \n","FUNDILAG: CARACTERES EXCEDIDOS!",javax.swing.JOptionPane.WARNING_MESSAGE);
        evt.consume();
        }
    }//GEN-LAST:event_passKeyTyped

    private void txt_area_trabKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_area_trabKeyTyped
        if(txt_area_trab.getText().length() >= 40)
        {
        javax.swing.JOptionPane.showMessageDialog(this,"La cantidad de caracteres ingresados sobrepasaron el limite permitido! \n","FUNDILAG: CARACTERES EXCEDIDOS!",javax.swing.JOptionPane.WARNING_MESSAGE);
        evt.consume();
        }
    }//GEN-LAST:event_txt_area_trabKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(usr_registro_acces.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(usr_registro_acces.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(usr_registro_acces.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(usr_registro_acces.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new usr_registro_acces().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton exit_btn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JPasswordField pass;
    private javax.swing.JTextField txt_area_trab;
    private javax.swing.JTextField txt_nom;
    // End of variables declaration//GEN-END:variables
}
