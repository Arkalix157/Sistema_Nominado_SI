package Sistema_Nominado_Beta;
/**
 *
 * @author sheogorath
 */
public class LoginSQL_SisNom {

    public static void main(String[] args) {
        System.out.println("=======================================");
        System.out.println("[!] RASTREO DE OPERACIONES ACTIVADO.");
        System.out.println("=======================================\n");
        Login_Online login = new Login_Online ();
        login.setVisible(true);
    }
    
}
